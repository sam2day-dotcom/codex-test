<?php
/**
 * Plugin Name: Custom News Blocks
 * Description: Custom Gutenberg blocks for news websites.
 * Version: 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function cnb_register_blocks() {

    $blocks = [
        'news-slider',
    ];

    foreach ( $blocks as $block ) {
        register_block_type( __DIR__ . "/build/blocks/{$block}" );
    }
}
add_action( 'init', 'cnb_register_blocks' );

/**
 * تحميل ملفات مكتبة Swiper للسلايدر
 */
function cnb_enqueue_assets() {
    // تحميل ستايل المكتبة
    if ( ! is_admin() ) { // نحملها فقط في الواجهة الأمامية، المحرر سيحملها تلقائياً إذا كانت معرفة في block.json أو نحملها هنا
        wp_enqueue_style( 
            'swiper-css', 
            'https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css', 
            [], 
            '11.0.0' 
        );

        // تحميل جافاسكربت المكتبة
        wp_enqueue_script( 
            'swiper-js', 
            'https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js', 
            [], 
            '11.0.0', 
            true 
        );
    }
}
// تحميل في الواجهة الأمامية
add_action( 'wp_enqueue_scripts', 'cnb_enqueue_assets' );

/**
 * تحميل الملفات داخل المحرر (Gutenberg) ليعمل الـ Preview
 */
function cnb_enqueue_editor_assets() {
    wp_enqueue_style( 'swiper-css', 'https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css', [], '11.0.0' );
    wp_enqueue_script( 'swiper-js', 'https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js', [], '11.0.0', true );
}
add_action( 'enqueue_block_editor_assets', 'cnb_enqueue_editor_assets' );